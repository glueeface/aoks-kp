import subprocess

subprocess.call(['.\compile.bat'])
