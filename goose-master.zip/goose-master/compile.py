import subprocess

subprocess.call(['sh', './compile.sh'])
